#!/bin/bash
cd autoshopDjimbo3.1&&python3.9 main.py